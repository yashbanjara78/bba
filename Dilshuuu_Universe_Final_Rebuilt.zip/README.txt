# Dilshuuu Universe 💫

This is the full website for Dilshuu's BBA journey, including:
- 3-Year Roadmap
- Dilshuuu ka Sewak (ChatGPT-powered)
- Weekly Planner
- Tasks, Progress, Badges, Resources

To activate ChatGPT AI:
1. Get your OpenAI API key from https://platform.openai.com/account/api-keys
2. Copy it into a file named `.env` like this:
   OPENAI_API_KEY=your_key_here